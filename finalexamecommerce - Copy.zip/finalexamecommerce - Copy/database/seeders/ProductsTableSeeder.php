<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $now = now();
        DB::table('products')->insert([
            'name' => 'Sweater',
            'image' => 'https://i.pinimg.com/736x/1b/3f/25/1b3f255eedca276114c5ee779db3063d.jpg',
            'stock' => 15,
            'price' => 115000,
            'category_id' => 1,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('products')->insert([
            'name' => 'Pink Sweater',
            'image' => 'https://i.pinimg.com/736x/24/4d/9a/244d9ae87ca19485a2eea1274ee8409a.jpg',
            'stock' => 15,
            'price' => 75000,
            'category_id' => 1,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('products')->insert([
            'name' => 'T-Shirt',
            'image' => 'https://i.pinimg.com/736x/a6/af/8e/a6af8e288339212b84edba9675a3563a.jpg',
            'stock' => 15,
            'price' => 115000,
            'category_id' => 2,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('products')->insert([
            'name' => 'White T-Shirt',
            'image' => 'https://i.pinimg.com/736x/51/8d/c4/518dc467055a803275c48c06b0e95fd4.jpg',
            'stock' => 20,
            'price' => 85000,
            'category_id' => 2,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('products')->insert([
            'name' => 'Blue Skirt',
            'image' => 'https://i.pinimg.com/736x/fc/15/53/fc1553708d1257805c6aa41bf0467c8f.jpg',
            'stock' => 10,
            'price' => 105000,
            'category_id' => 3,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('products')->insert([
            'name' => 'Pink Skirt',
            'image' => 'https://i.pinimg.com/736x/e7/ad/d6/e7add6095a26b18f0e5719317eb987ca.jpg',
            'stock' => 7,
            'price' => 78000,
            'category_id' => 3,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('products')->insert([
            'name' => 'Beige Cargo Pants',
            'image' => 'https://i.pinimg.com/736x/9d/e6/dc/9de6dc607cab728d20c8d9c6bd32d156.jpg',
            'stock' => 15,
            'price' => 120000,
            'category_id' => 4,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('products')->insert([
            'name' => 'Jeans Short Pants',
            'image' => 'https://i.pinimg.com/736x/5f/ee/46/5fee4620c421279f4827c039846fa871.jpg',
            'stock' => 15,
            'price' => 135000,
            'category_id' => 5,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }
}
